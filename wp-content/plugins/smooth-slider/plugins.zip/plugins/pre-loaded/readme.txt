=== <a href="http://krisjaydesigns.com" target="_blank">Pre Loaded - CSS Image Preloader</a> ===
Contributors: krisjay, GraphicDreams
Author: Kris Jonasson - Winnipeg, Canada.
Author URI: http://krisjaydesigns.com
Tags: login, custom, plugin, preload, admin, images, pages 
Version: 0.1
Requires at least: 2.0.2
Tested up to: 2.9.2
Stable tag: 0.1

 Preload Images Contained Within ALL Referenced CSS Files. Uses jQuery to Preload to DOM. Plug n Play. Upload, activate and sit back!

== Description ==

Preload Images Contained Within ALL Referenced CSS Files. Uses jQuery to Preload to DOM. Plug n Play. Upload, activate and sit back!

== Installation ==

**What To Do**

1. Download the zip to your hardrive.
2. Upload to your 'Plugin' Directory via On-site Uploader (zip).
3. Second Last, Click 'Activate Plugin'.
4. Enjoy.

== Frequently Asked Questions ==

= What Images Are Loaded? =

*ALL* Images within every referenced CSS File Within That Given Page.

== Screenshots ==

Check out a demo incorporated with my 'Transitions' plugin @ <a href="http://testing.gdsweb.ca/" target="blank">Demo</a>. It's used to pre-load the css images for a quick page transitioning fade effect.

== Changelog ==

= 0.1 =
* First Release.


`<?php code(); // goes in backticks ?>`
